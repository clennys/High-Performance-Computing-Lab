The numbers of Rosa seem to roughly match the single core performance:

https://sites.utexas.edu/jdm4372/2023/12/19/the-evolution-of-single-core-bandwidth-in-multicore-systems-update/
